//-------------------------------
// Matthew Acs 
// COP 4020
// Mini Compiler - Parser Project
// 11/15/2022
//-------------------------------

/*

    prog        ->  begin stmt_list end

    stmt_list   ->  stmt ; stmt_list
                 |  stmt
				 |	stmt;

    stmt        ->  var = expr

    var         ->  A | B | C

    expr        ->  var + expr
                 |  var - expr
                 |  var
*/

// Dependencies
#include    <iostream>
#include    <fstream>
#include    <cctype>

#include    "token.h"
#include    "functions.h"

using namespace std;

// Global Declarations
ifstream ifs;                   // input file stream used by lexan
SymTab   symtab;                // global symbol table
Token    token;                 // global token
int      lookahead = 0;         // no look ahead token yet
int      temp_op_1 = 0;         // used for post-fix expression printing
int      flag = 0;              // flag for formatting
int      dbg = 1;               // debut is ON


// Main program driver
int main( )
{
    ifs = get_ifs( );           // open an input file stream w/ the program
    init_kws( );                // initialize keywords in the symtab
    match( lookahead );         // get the first input token
    prog( );                    // call prog function

    return 0;
}

// prog Function
// -------------------------------
// The first function that is called
// It processes the prog production rule
void prog(){
    
    if (token.tokstr() == "begin"){     // if the first token is begin
        emit(lookahead);                // print the token
        printf("\n");                   // print a new line
        match(KW);                      // get the next input token
    }
    else{
        error(lookahead);               // otherwise throw an error
    }
    
    stmt_list();                        // call the stmt_list function
    
    if (token.tokstr() == "end"){       // if the last token is end
        if (flag==0){                   // if the flag is zero
            printf("\n");               // print a new line
        }  
        emit(lookahead);                // print the last token
        match(KW);                      // get the final input token
    }
    else{
        error(lookahead);               // otherwise throw an error
    }

}

// stmt_list Function
// -------------------------------
// Processes the stmt_list production rule
void stmt_list(){
    stmt();                             // calls the stmt function
    flag = 0;                           // sets the flag to zero
    if (lookahead == ';'){              // if the next token is ;
        emit(lookahead);                // print the token
        match(';');                     // get the next token

        if (lookahead != KW){           // if the next token is not a keyword
            stmt_list();                // call the stmt_list function
        }
        else if(lookahead == KW){       // else if the next token is a keyword
            flag = 1;                   // set the flag to 1
        }
    }
}

// stmt Function
// -------------------------------
// Processes the stmt production rule
void stmt(){
    temp_op_1 = 0;                      // sets the temp_op_1 variable to zero (used for postfix printing)
    var();                              // calls the var function
    int equal = lookahead;              // saves the equal sign token to a variable
    match('=');                         // gets the next token
    expr();                             // calls the expr function
    emit(equal);                        // prints the equal sign
    
}

// var Function
// -------------------------------
// Processes the var production rule
void var(){
    emit(lookahead);                    // prints the token
    match(ID);                          // gets the next token
}

// expr Function
// -------------------------------
// Processes the expr production rule
void expr(){
    var();                              // calls the var function
    if (temp_op_1 != 0){                // if temp_op_1 is not zero
        emit(temp_op_1);                // print the token
    }
    if (lookahead == '+'){              // if the next token is +
        temp_op_1 = lookahead;          // store it in temp_op_1
        match('+');                     // get the next token
        expr();                         // call the expr function
    }
    if (lookahead == '-'){              // if the next token is -
        temp_op_1 = lookahead;          // store it in temp_op_1
        match('-');                     // get the next token
        expr();                         // call the expr function
    }
}

// The match utility method was used to both get the next token
// and to do error checking. The emit utility method was used 
// to print the tokens to the console.

// utility methods
void emit( int t )
{
    switch( t )
    {
        case '+': case '-': case '=':
            cout << char( t ) << ' ';
            break;

        case ';':
            cout << ";\n";
            break;

        case '\n':
            cout << "\n";
            break;

        case ID:
        case KW:
        case UID:
            cout << symtab.tokstr( token.tokvalue( ) ) << ' ';
            break;

        default:
            cout << "'token " << t << ", tokvalue "
                 << token.tokvalue( ) << "' ";
            break;
    }
}

void error( int t, int expt, const string &str )
{
    cerr << "\nunexpected token '";
    if( lookahead == DONE )
    {
        cerr << "EOF";
    }
    else
    {
        cerr << token.tokstr( );
    }
    cerr << "' of type " << lookahead;

    switch( expt )
    {
        case 0:         // default value; nothing to do
            break;

        case ID:
            cout << " while looking for an ID";
            break;

        case KW:
            cout << " while looking for KW '" << str << "'";
            break;

        default:
            cout << " while looking for '" << char( expt ) << "'";
            break;
    }

    cerr << "\nsyntax error.\n";

    exit( 1 );
}

void match( int t )
{
    if( lookahead == t )
    {
        token = lexan( );               // get next token
        lookahead = token.toktype( );   // lookahed contains the tok type
    }
    else
    {
        error( t );
    }
}

